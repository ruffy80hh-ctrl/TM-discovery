<?php
session_start();

// POST-Daten lesen
$rawPostData = file_get_contents("php://input");
$data = json_decode($rawPostData, true);

// Response Token berechnen
$rT = 12345; // Default-Wert
if (isset($data['requestToken']) && isset($_SERVER['HTTP_X_PARSE_APP_DATA'])) {
    $hexData = $_SERVER['HTTP_X_PARSE_APP_DATA'];
    $rT = hexdec($hexData);
}

// Response JSON
$response = [
    'result' => [
        'newApkUrl' => '',
        'newVersionName' => '',
        'shouldUpdateGooglePlayVersion' => false,
        'forceAutoUpdate' => false,
        'stagedRolloutDays' => 0,
        'isActivated' => true,
        'deviceName' => 'TV',
        'account' => 'andy@hax.net',
        'responseToken' => $rT
    ]
];

// Header und Output
header('Content-Type: application/json');
echo json_encode($response, JSON_PRETTY_PRINT);

session_destroy();
?>