<?php
// Vereinfachte Debug API für mobile App-Anfragen
// Speichern als: htdocs/api/debug_mobile_fixed.php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Parse-App-Data, User-Agent');

// Log-Datei erstellen
$logFile = __DIR__ . '/mobile_debug.log';

// Sichere Datensammlung ohne getallheaders()
$debugData = [
    'timestamp' => date('Y-m-d H:i:s'),
    'method' => $_SERVER['REQUEST_METHOD'] ?? 'unknown',
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
    'request_uri' => $_SERVER['REQUEST_URI'] ?? 'unknown',
    'remote_addr' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    'http_host' => $_SERVER['HTTP_HOST'] ?? 'unknown',
    'content_type' => $_SERVER['CONTENT_TYPE'] ?? 'unknown',
    'query_string' => $_SERVER['QUERY_STRING'] ?? 'unknown'
];

// Sicheres Logging
$logEntry = "=== MOBILE REQUEST ===\n";
$logEntry .= "Time: " . $debugData['timestamp'] . "\n";
$logEntry .= "Method: " . $debugData['method'] . "\n";
$logEntry .= "User-Agent: " . $debugData['user_agent'] . "\n";
$logEntry .= "URI: " . $debugData['request_uri'] . "\n";
$logEntry .= "IP: " . $debugData['remote_addr'] . "\n";
$logEntry .= "====================\n\n";

// In Log-Datei schreiben
@file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);

// Einfache JSON-Antwort
$response = [
    'status' => 'debug_success',
    'message' => 'Mobile request logged successfully',
    'timestamp' => date('Y-m-d H:i:s'),
    'method' => $debugData['method'],
    'user_agent' => substr($debugData['user_agent'], 0, 50) . '...'
];

echo json_encode($response, JSON_PRETTY_PRINT);
?>