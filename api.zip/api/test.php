<?php
// Simple API test - use this to test if the API endpoint is working
// Access via: https://lautaros2.xo.je/api/test.php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Parse-App-Data');

// Simple test response
$response = [
    'status' => 'success',
    'message' => 'API endpoint is working correctly',
    'timestamp' => date('Y-m-d H:i:s'),
    'server_info' => [
        'php_version' => phpversion(),
        'server_name' => $_SERVER['SERVER_NAME'] ?? 'unknown',
        'request_method' => $_SERVER['REQUEST_METHOD'] ?? 'unknown'
    ]
];

echo json_encode($response, JSON_PRETTY_PRINT);
?>
